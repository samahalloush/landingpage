/**
 * 
 * Landing Page First project exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/

// navigation global  var
const sections = document.querySelectorAll('section');
const Ul = document.querySelector('ul');
const fragment = document.createDocumentFragment();
const goTop = document.getElementById('topScroll');

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

// bulid navbar 
sections.forEach(section => {
    // data-nav section
    const navData = section.getAttribute("data-nav");
    // IdAttribute section
    const IdAttribute = section.getAttribute('id');
    // new li 
    const newli = document.createElement("li");
    // new link
    const links = document.createElement("a");
    // style nav
    links.classList.add("menu__link");
    // call href from sections id
    links.setAttribute('href', IdAttribute);
    // Scroll to section on link click
    links.addEventListener('click', e => {
        e.preventDefault();
        section.scrollIntoView({ behavior: "smooth" })
    });
    // add name to sections from data-nav
    const text = document.createTextNode(navData);

    links.appendChild(text);
    newli.appendChild(links);
    fragment.appendChild(newli);
});
//append in fragment to make performance improvements  
Ul.appendChild(fragment);

window.addEventListener('scroll', () => {

    //  Chek  Section when remove the active class
    const activesec = document.getElementsByClassName('your-active-class')[0];

    if (activesec !== undefined) {
        activesec.classList.remove('your-active-class')
    }
    //  Chek section when remove the nav-class from the nav-bar
    const ActiveNav = document.getElementsByClassName('navactive')[0];

    if (ActiveNav !== undefined) {
        ActiveNav.classList.remove('navactive')
    }
    // Set sections as active
    sections.forEach(section => {

        const react = section.getBoundingClientRect();

        if (react.top >= -50 && react.top < 394) {

            section.classList.add('your-active-class');

            // nav-bar  active
            const listactive = document.querySelectorAll(`a[href='${section.id}']`)[0].parentElement;

            listactive.classList.add("navactive");

            // Go To Top g
            if (section.id == "section1") {

                goTop.style.display = 'none';
            } else {

                goTop.style.display = 'block';
            }
        }
    })
})







