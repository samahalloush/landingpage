# First Project Landing Page Project  (Front End Developer Udacity Nanodegree)
## I used ( HTML, CSS, Javascript)

A landing page is the transformation of a static page to a page that allows some sort of interaction. The dynamicity is achieved through javascript.

## Instructions
this project has some HTML and CSS styling to display a static version of the Landing Page project. I have convert this project from a static project to an interactive one and modifying the HTML and CSS files, but primarily the JavaScript it used for create navbar links bases on content ,when a section is in the viewport it shows the active state of that section.

There are 4 sections that have been added to the page

for display which section is being viewed while scrolling through the page  and It is also display on desktop and phones.
 
 ## project  instructions in the Udacity Classroom helped me for finished project.